export class User
{
    userid: any;
    firstname: string;
    lastname :string;
    employeeid : string;
}