export class ParentTask{

    parentid: any;
    parenttask: string;
}