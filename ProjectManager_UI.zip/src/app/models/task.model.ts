
export class Task
{
    projectid: any;
    parentid: any;
    userid: any;
    taskid: any;
    taskname: string;
    startdate: any;
    enddate: any;
    priority: any;
    status: any;
}